import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Phone, PhoneOff, Video, VideoOff, Mic, MicOff, 
  Volume2, Volume1, VolumeX, Shield, User, SwitchCamera, Sparkles,
  AlertCircle, Radio, Check, Activity, ChevronDown, Minimize2, Maximize2
} from 'lucide-react';
import { doc, setDoc, onSnapshot, updateDoc, collection, addDoc, getDoc } from 'firebase/firestore';

export interface CallSession {
  id: string;
  type: 'voice' | 'video';
  status: 'dialing' | 'ringing' | 'connected' | 'ended' | 'declined';
  isIncoming: boolean;
  partnerUsername: string;
  partnerName: string;
  partnerAvatarSeed: string;
  partnerAvatarUrl?: string;
  startedAt?: number;
  startTimeStr?: string;
}

export interface CallEndMetadata {
  callId: string;
  callType: 'voice' | 'video';
  status: 'answered' | 'missed' | 'unanswered' | 'declined';
  startTime: string;
  endTime: string;
  durationSeconds: number;
  durationFormatted: string;
}

interface CallModalProps {
  session: CallSession;
  userUsername: string;
  userDisplayName: string;
  db: any; // Firestore instance
  isFirebaseConfigured: boolean;
  onEndCall: (meta: CallEndMetadata) => void;
  onAnswerCall: () => void;
  isMinimized?: boolean;
  onToggleMinimize?: (minimized: boolean) => void;
}

const ICE_SERVERS: RTCConfiguration = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
    { urls: 'stun:stun2.l.google.com:19302' },
    { urls: 'stun:stun3.l.google.com:19302' },
    { urls: 'stun:stun4.l.google.com:19302' },
    { urls: 'stun:global.stun.twilio.com:3478' }
  ],
  iceCandidatePoolSize: 10,
  bundlePolicy: 'max-bundle',
  rtcpMuxPolicy: 'require'
};

export const CallModal: React.FC<CallModalProps> = ({
  session,
  userUsername,
  userDisplayName,
  db,
  isFirebaseConfigured,
  onEndCall,
  onAnswerCall,
  isMinimized: isMinimizedProp,
  onToggleMinimize,
}) => {
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(session.type === 'voice');
  // Voice calls default to false (earpiece/handset mode). Video calls default to true (speakerphone).
  const [isSpeakerOn, setIsSpeakerOn] = useState(session.type === 'video');
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [callDuration, setCallDuration] = useState(0);
  const [micVolume, setMicVolume] = useState(0);
  const [remoteAudioVolume, setRemoteAudioVolume] = useState(0);
  const [hasMediaError, setHasMediaError] = useState<string | null>(null);
  const [isRemoteConnected, setIsRemoteConnected] = useState(session.status === 'connected');
  const [iceState, setIceState] = useState<string>('new');
  const [isSwapped, setIsSwapped] = useState(false); // WhatsApp-style tap to swap main/pip feeds
  const [internalMinimized, setInternalMinimized] = useState(false); // PiP floating mini-window mode
  const isMinimized = isMinimizedProp !== undefined ? isMinimizedProp : internalMinimized;

  const setIsMinimized = (val: boolean) => {
    setInternalMinimized(val);
    onToggleMinimize?.(val);
  };
  const [ringCountdown, setRingCountdown] = useState<number>(() => {
    const elapsed = Math.floor((Date.now() - (session.startedAt || Date.now())) / 1000);
    return Math.max(0, 45 - elapsed);
  });

  // Track timestamps & refs
  const startTimeStrRef = useRef<string>(
    session.startTimeStr || new Date(session.startedAt || Date.now()).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  );
  const wasConnectedRef = useRef<boolean>(session.status === 'connected');
  const durationTimerRef = useRef<any>(null);
  const callDurationRef = useRef<number>(0);

  // Stable Media Streams & Peer Connection Refs (Never swap DOM refs directly in JSX!)
  const mainVideoElementRef = useRef<HTMLVideoElement | null>(null);
  const pipVideoElementRef = useRef<HTMLVideoElement | null>(null);
  const miniVideoElementRef = useRef<HTMLVideoElement | null>(null);
  const remoteAudioRef = useRef<HTMLAudioElement | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const remoteStreamRef = useRef<MediaStream | null>(null);
  const peerConnectionRef = useRef<RTCPeerConnection | null>(null);
  const pendingCandidatesRef = useRef<RTCIceCandidateInit[]>([]);
  const isPeerConnectionInitializedRef = useRef<boolean>(false);
  const isSettingRemoteDescriptionRef = useRef<boolean>(false);
  const broadcastChannelRef = useRef<BroadcastChannel | null>(null);
  const unsubscribeCallDocRef = useRef<(() => void) | null>(null);
  const unsubscribeCandidatesRef = useRef<(() => void) | null>(null);

  // Audio Analyzers
  const localAudioCtxRef = useRef<AudioContext | null>(null);
  const localAnalyserRef = useRef<AnalyserNode | null>(null);
  const remoteAudioCtxRef = useRef<AudioContext | null>(null);
  const remoteAnalyserRef = useRef<AnalyserNode | null>(null);
  const audioIntervalRef = useRef<any>(null);

  // Tone generation refs
  const ringtoneIntervalRef = useRef<any>(null);
  const gainNodeRef = useRef<GainNode | null>(null);

  // Keep duration ref in sync
  useEffect(() => {
    callDurationRef.current = callDuration;
  }, [callDuration]);

  // Handle speakerphone / hands-free mode vs handset/earpiece mode
  useEffect(() => {
    if (remoteAudioRef.current) {
      // Set volume proportional to hands-free vs earpiece mode
      remoteAudioRef.current.volume = isSpeakerOn ? 1.0 : 0.45;
      // Try to route output device if setSinkId is supported by browser/device
      if ('setSinkId' in remoteAudioRef.current && typeof (remoteAudioRef.current as any).setSinkId === 'function') {
        if (navigator.mediaDevices && navigator.mediaDevices.enumerateDevices) {
          navigator.mediaDevices.enumerateDevices().then(devices => {
            const audioOutputs = devices.filter(d => d.kind === 'audiooutput');
            if (audioOutputs.length > 0) {
              const target = isSpeakerOn
                ? audioOutputs.find(d => d.label.toLowerCase().includes('speaker')) || audioOutputs[0]
                : audioOutputs.find(d => d.label.toLowerCase().includes('earpiece') || d.label.toLowerCase().includes('receiver') || d.deviceId === 'default') || audioOutputs[0];
              if (target?.deviceId) {
                (remoteAudioRef.current as any).setSinkId(target.deviceId).catch(() => {});
              }
            }
          }).catch(() => {});
        }
      }
    }
  }, [isSpeakerOn]);

  // Synthesized tone generator for dialing / ringing
  const startAudioTone = useCallback((mode: 'dialing' | 'ringing') => {
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) return;
      
      const ctx = new AudioContextClass();
      const gainNode = ctx.createGain();
      gainNode.connect(ctx.destination);
      gainNodeRef.current = gainNode;
      gainNode.gain.setValueAtTime(0, ctx.currentTime);

      const playTone = () => {
        if (ctx.state === 'suspended') {
          ctx.resume().catch(() => {});
        }

        const osc1 = ctx.createOscillator();
        const osc2 = ctx.createOscillator();
        
        osc1.connect(gainNode);
        osc2.connect(gainNode);

        if (mode === 'dialing') {
          osc1.frequency.setValueAtTime(350, ctx.currentTime);
          osc2.frequency.setValueAtTime(440, ctx.currentTime);
        } else {
          osc1.frequency.setValueAtTime(440, ctx.currentTime);
          osc2.frequency.setValueAtTime(480, ctx.currentTime);
        }

        osc1.start();
        osc2.start();

        gainNode.gain.linearRampToValueAtTime(0.06, ctx.currentTime + 0.1);

        setTimeout(() => {
          try {
            gainNode.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.2);
            setTimeout(() => {
              osc1.stop();
              osc2.stop();
              osc1.disconnect();
              osc2.disconnect();
            }, 300);
          } catch (e) {}
        }, 1200);
      };

      playTone();
      ringtoneIntervalRef.current = setInterval(playTone, 3800);
    } catch (e) {
      console.warn("Audio tone generation warning:", e);
    }
  }, []);

  const stopAudioTone = useCallback(() => {
    if (ringtoneIntervalRef.current) {
      clearInterval(ringtoneIntervalRef.current);
      ringtoneIntervalRef.current = null;
    }
    try {
      if (gainNodeRef.current) {
        gainNodeRef.current.disconnect();
        gainNodeRef.current = null;
      }
    } catch (e) {}
  }, []);

  const sessionRef = useRef(session);
  useEffect(() => {
    sessionRef.current = session;
  }, [session]);

  const isMinimizedRef = useRef(isMinimized);
  useEffect(() => {
    isMinimizedRef.current = isMinimized;
  }, [isMinimized]);

  // Voice level analyzer for local & remote audio
  const setupVoiceAnalyzer = (localStream: MediaStream, remoteStream?: MediaStream) => {
    try {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtxClass) return;

      // Local analyzer
      if (localStream.getAudioTracks().length > 0 && !localAudioCtxRef.current) {
        const localCtx = new AudioCtxClass();
        const localSrc = localCtx.createMediaStreamSource(localStream);
        const localAnalyser = localCtx.createAnalyser();
        localAnalyser.fftSize = 32;
        localSrc.connect(localAnalyser);
        localAudioCtxRef.current = localCtx;
        localAnalyserRef.current = localAnalyser;
      }

      // Remote analyzer
      if (remoteStream && remoteStream.getAudioTracks().length > 0 && !remoteAudioCtxRef.current) {
        const remoteCtx = new AudioCtxClass();
        const remoteSrc = remoteCtx.createMediaStreamSource(remoteStream);
        const remoteAnalyser = remoteCtx.createAnalyser();
        remoteAnalyser.fftSize = 32;
        remoteSrc.connect(remoteAnalyser);
        remoteAudioCtxRef.current = remoteCtx;
        remoteAnalyserRef.current = remoteAnalyser;
      }

      if (!audioIntervalRef.current) {
        audioIntervalRef.current = setInterval(() => {
          // If minimized, do not trigger component re-renders to ensure 120fps buttery smooth UI & dragging
          if (isMinimizedRef.current) return;

          if (localAnalyserRef.current) {
            const data = new Uint8Array(localAnalyserRef.current.frequencyBinCount);
            localAnalyserRef.current.getByteFrequencyData(data);
            const sum = data.reduce((acc, val) => acc + val, 0);
            const avg = sum / data.length;
            const newVol = Math.min(100, Math.floor((avg / 255) * 100));
            setMicVolume(prev => (Math.abs(prev - newVol) > 4 ? newVol : prev));
          }
          if (remoteAnalyserRef.current) {
            const data = new Uint8Array(remoteAnalyserRef.current.frequencyBinCount);
            remoteAnalyserRef.current.getByteFrequencyData(data);
            const sum = data.reduce((acc, val) => acc + val, 0);
            const avg = sum / data.length;
            const newVol = Math.min(100, Math.floor((avg / 255) * 100));
            setRemoteAudioVolume(prev => (Math.abs(prev - newVol) > 4 ? newVol : prev));
          }
        }, 150);
      }
    } catch (e) {
      console.warn("Audio analyser hook notice:", e);
    }
  };

  // High Quality Stream Capture with graceful fallback
  const getLocalMediaStream = async (targetFacingMode: 'user' | 'environment'): Promise<MediaStream> => {
    const isVideo = session.type === 'video';
    const constraints: MediaStreamConstraints = {
      audio: {
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true,
        channelCount: 2,
        sampleRate: 48000
      },
      video: isVideo ? {
        facingMode: targetFacingMode,
        width: { ideal: 1280, min: 640 },
        height: { ideal: 720, min: 480 },
        frameRate: { ideal: 30, min: 20 }
      } : false
    };

    try {
      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      setHasMediaError(null);
      return stream;
    } catch (err: any) {
      console.warn("High-quality media capture failed, attempting standard constraints:", err);
      try {
        const fallbackStream = await navigator.mediaDevices.getUserMedia({
          audio: true,
          video: isVideo ? { facingMode: targetFacingMode } : false
        });
        setHasMediaError(null);
        return fallbackStream;
      } catch (fallbackErr: any) {
        console.error("Microphone/Camera permission error:", fallbackErr);
        setHasMediaError(fallbackErr.message || "Microphone/Camera permission is required for live voice and video.");
        
        // Generate a silent audio track fallback to prevent RTCPeerConnection initialization failure
        try {
          const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
          const dummyCtx = new AudioContextClass();
          const osc = dummyCtx.createOscillator();
          const gain = dummyCtx.createGain();
          gain.gain.value = 0; // Silent
          osc.connect(gain);
          const dst = gain.connect(dummyCtx.createMediaStreamDestination()) as any;
          osc.start();
          return dst.stream;
        } catch {
          return new MediaStream();
        }
      }
    }
  };

  // Attach streams to current video/audio DOM elements
  const attachStreamsToElements = useCallback(() => {
    const isVideo = session.type === 'video';
    const localStream = localStreamRef.current;
    const remoteStream = remoteStreamRef.current;
    const isConnectedNow = session.status === 'connected' || isRemoteConnected;

    if (isVideo) {
      // While dialing/connecting: User's local camera stream is immediately active fullscreen in background
      // Once connected: Remote stream takes the main stage (or local if swapped)
      const mainStream = !isConnectedNow
        ? localStream
        : (isSwapped ? localStream : (remoteStream && remoteStream.getVideoTracks().length > 0 ? remoteStream : null));

      // Small second frame (PiP) is ONLY shown once connection is established
      const pipStream = !isConnectedNow
        ? null
        : (isSwapped ? (remoteStream && remoteStream.getVideoTracks().length > 0 ? remoteStream : null) : localStream);

      // Dominant stream for floating mini-window (PiP): Strictly REMOTE feed only
      const miniStream = (remoteStream && remoteStream.getVideoTracks().length > 0) ? remoteStream : null;

      if (mainVideoElementRef.current) {
        if (mainStream && mainVideoElementRef.current.srcObject !== mainStream) {
          mainVideoElementRef.current.srcObject = mainStream;
          mainVideoElementRef.current.play().catch(() => {});
        } else if (!mainStream && mainVideoElementRef.current.srcObject !== null) {
          mainVideoElementRef.current.srcObject = null;
        }
      }

      if (pipVideoElementRef.current) {
        if (pipStream && pipVideoElementRef.current.srcObject !== pipStream) {
          pipVideoElementRef.current.srcObject = pipStream;
          pipVideoElementRef.current.play().catch(() => {});
        } else if (!pipStream && pipVideoElementRef.current.srcObject !== null) {
          pipVideoElementRef.current.srcObject = null;
        }
      }

      if (miniVideoElementRef.current) {
        if (miniStream && miniVideoElementRef.current.srcObject !== miniStream) {
          miniVideoElementRef.current.srcObject = miniStream;
          miniVideoElementRef.current.play().catch(() => {});
        } else if (!miniStream && miniVideoElementRef.current.srcObject !== null) {
          miniVideoElementRef.current.srcObject = null;
        }
      }

      // Ensure remote audio track plays if present
      if (remoteAudioRef.current && remoteStream && remoteStream.getAudioTracks().length > 0) {
        if (remoteAudioRef.current.srcObject !== remoteStream) {
          remoteAudioRef.current.srcObject = remoteStream;
          remoteAudioRef.current.play().catch(() => {});
        }
      }
    } else {
      // Voice mode: Remote Audio element handles remote sound
      if (remoteAudioRef.current && remoteStream && remoteStream.getAudioTracks().length > 0) {
        if (remoteAudioRef.current.srcObject !== remoteStream) {
          remoteAudioRef.current.srcObject = remoteStream;
          remoteAudioRef.current.play().catch(() => {});
        }
      }
    }
  }, [isSwapped, isRemoteConnected, session.status, session.type]);

  // Re-attach streams whenever swap state, connection, or minimized state changes
  useEffect(() => {
    attachStreamsToElements();
    const t = setTimeout(() => {
      attachStreamsToElements();
    }, 40);
    return () => clearTimeout(t);
  }, [isSwapped, isRemoteConnected, session.status, isMinimized, attachStreamsToElements]);

  // Add queued ICE candidates once remote description is set
  const processPendingCandidates = async (pc: RTCPeerConnection) => {
    if (!pc.remoteDescription || !pc.remoteDescription.type) return;
    const candidates = [...pendingCandidatesRef.current];
    pendingCandidatesRef.current = [];
    for (const candidate of candidates) {
      if (candidate && candidate.candidate) {
        try {
          await pc.addIceCandidate(new RTCIceCandidate(candidate));
          console.log("Flushed queued ICE candidate successfully");
        } catch (e) {
          console.warn("Error adding queued ICE candidate:", e);
        }
      }
    }
  };

  // Safe helper to add candidate immediately or buffer if remote description not yet set
  const addOrBufferCandidate = async (pc: RTCPeerConnection, candidateData: any) => {
    if (!candidateData || !candidateData.candidate) return;
    if (pc.remoteDescription && pc.remoteDescription.type) {
      try {
        await pc.addIceCandidate(new RTCIceCandidate(candidateData));
      } catch (err) {
        console.warn("ICE candidate add notice:", err);
      }
    } else {
      pendingCandidatesRef.current.push(candidateData);
    }
  };

  // Cleanup helper
  const cleanupCall = useCallback(() => {
    stopAudioTone();
    if (unsubscribeCallDocRef.current) {
      unsubscribeCallDocRef.current();
      unsubscribeCallDocRef.current = null;
    }
    if (unsubscribeCandidatesRef.current) {
      unsubscribeCandidatesRef.current();
      unsubscribeCandidatesRef.current = null;
    }
    if (durationTimerRef.current) {
      clearInterval(durationTimerRef.current);
      durationTimerRef.current = null;
    }
    if (audioIntervalRef.current) {
      clearInterval(audioIntervalRef.current);
      audioIntervalRef.current = null;
    }
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach(track => track.stop());
      localStreamRef.current = null;
    }
    if (peerConnectionRef.current) {
      peerConnectionRef.current.close();
      peerConnectionRef.current = null;
    }
    if (broadcastChannelRef.current) {
      broadcastChannelRef.current.close();
      broadcastChannelRef.current = null;
    }
    try {
      if (localAudioCtxRef.current && localAudioCtxRef.current.state !== 'closed') {
        localAudioCtxRef.current.close().catch(() => {});
        localAudioCtxRef.current = null;
      }
      if (remoteAudioCtxRef.current && remoteAudioCtxRef.current.state !== 'closed') {
        remoteAudioCtxRef.current.close().catch(() => {});
        remoteAudioCtxRef.current = null;
      }
    } catch (e) {}
  }, [stopAudioTone]);

  // Main stable WebRTC peer connection initializer
  const initWebRTC = useCallback(async () => {
    if (isPeerConnectionInitializedRef.current && peerConnectionRef.current) {
      return;
    }
    isPeerConnectionInitializedRef.current = true;

    const callDocRef = (isFirebaseConfigured && db && session.id) ? doc(db, 'calls', session.id) : null;

    // 1. Acquire Local Media Stream
    const localStream = await getLocalMediaStream(facingMode);
    localStreamRef.current = localStream;

    // Attach to preview immediately
    attachStreamsToElements();
    setupVoiceAnalyzer(localStream);

    // 2. Initialize RTCPeerConnection
    const pc = new RTCPeerConnection(ICE_SERVERS);
    peerConnectionRef.current = pc;

    // 3. Add all local media tracks to peer connection
    localStream.getTracks().forEach(track => {
      pc.addTrack(track, localStream);
    });

    // 4. Handle incoming remote media tracks
    pc.ontrack = (event) => {
      console.log("WebRTC ontrack event received:", event.track.kind, event.streams);

      let remoteStream = remoteStreamRef.current;
      if (!remoteStream) {
        remoteStream = (event.streams && event.streams[0]) ? event.streams[0] : new MediaStream();
        remoteStreamRef.current = remoteStream;
      }

      if (event.streams && event.streams[0]) {
        remoteStreamRef.current = event.streams[0];
        remoteStream = event.streams[0];
      } else {
        if (!remoteStream.getTracks().some(t => t.id === event.track.id)) {
          remoteStream.addTrack(event.track);
        }
      }

      // Bind streams to audio and video elements
      attachStreamsToElements();
      setupVoiceAnalyzer(localStream, remoteStream);

      setIsRemoteConnected(true);
      wasConnectedRef.current = true;
      stopAudioTone();
    };

    // 5. ICE Connection & Signaling State Monitoring
    pc.oniceconnectionstatechange = () => {
      console.log("ICE Connection State changed:", pc.iceConnectionState);
      setIceState(pc.iceConnectionState);
      if (pc.iceConnectionState === 'connected' || pc.iceConnectionState === 'completed') {
        setIsRemoteConnected(true);
        wasConnectedRef.current = true;
        stopAudioTone();
        attachStreamsToElements();
      }
    };

    pc.onconnectionstatechange = () => {
      console.log("Peer Connection State changed:", pc.connectionState);
      if (pc.connectionState === 'connected') {
        setIsRemoteConnected(true);
        wasConnectedRef.current = true;
        stopAudioTone();
        attachStreamsToElements();
      }
    };

    // 6. Handle local ICE candidates and dispatch to Firestore & BroadcastChannel
    pc.onicecandidate = (event) => {
      if (event.candidate && session.id) {
        const candidateData = event.candidate.toJSON();
        const candidateType = session.isIncoming ? 'calleeCandidates' : 'callerCandidates';
        
        // Dispatch via Firestore
        if (callDocRef) {
          const candidatesCol = collection(callDocRef, candidateType);
          addDoc(candidatesCol, candidateData).catch(e => console.warn("ICE candidate push notice:", e));
        }

        // Dispatch via local BroadcastChannel accelerator
        if (broadcastChannelRef.current) {
          broadcastChannelRef.current.postMessage({
            type: 'ice-candidate',
            senderRole: session.isIncoming ? 'callee' : 'caller',
            candidate: candidateData
          });
        }
      }
    };

    // 7. Caller Flow: Create and push Offer
    if (!session.isIncoming) {
      try {
        const offer = await pc.createOffer({
          offerToReceiveAudio: true,
          offerToReceiveVideo: session.type === 'video'
        });
        await pc.setLocalDescription(offer);

        if (callDocRef) {
          await setDoc(callDocRef, {
            offer: { type: offer.type, sdp: offer.sdp },
            status: 'dialing',
            created_at: session.startedAt || Date.now()
          }, { merge: true });
        }

        if (broadcastChannelRef.current) {
          broadcastChannelRef.current.postMessage({
            type: 'offer',
            offer: { type: offer.type, sdp: offer.sdp }
          });
        }
      } catch (offerErr) {
        console.error("Failed to create WebRTC offer:", offerErr);
      }
    }

    // 8. Callee Flow: If answered, handle existing offer or prepare answer
    if (session.isIncoming) {
      if (callDocRef && !isSettingRemoteDescriptionRef.current) {
        try {
          const snap = await getDoc(callDocRef);
          if (snap.exists()) {
            const callData = snap.data();
            if (callData.offer && !pc.currentRemoteDescription && !isSettingRemoteDescriptionRef.current) {
              isSettingRemoteDescriptionRef.current = true;
              await pc.setRemoteDescription(new RTCSessionDescription(callData.offer));
              await processPendingCandidates(pc);

              const answer = await pc.createAnswer();
              await pc.setLocalDescription(answer);

              await setDoc(callDocRef, {
                answer: { type: answer.type, sdp: answer.sdp },
                status: 'connected',
                answered_at: Date.now()
              }, { merge: true });
              isSettingRemoteDescriptionRef.current = false;

              if (broadcastChannelRef.current) {
                broadcastChannelRef.current.postMessage({
                  type: 'answer',
                  answer: { type: answer.type, sdp: answer.sdp }
                });
              }
            }
          }
        } catch (calleeInitErr) {
          isSettingRemoteDescriptionRef.current = false;
          console.error("Callee answer initialization error:", calleeInitErr);
        }
      }
    }

    // 9. Subscribe to Remote ICE Candidates from subcollection
    if (callDocRef) {
      const candidatesToListen = session.isIncoming ? 'callerCandidates' : 'calleeCandidates';
      const candidatesCollection = collection(callDocRef, candidatesToListen);
      unsubscribeCandidatesRef.current = onSnapshot(
        candidatesCollection,
        (snapshot) => {
          snapshot.docChanges().forEach(async (change) => {
            if (change.type === 'added') {
              const candidateData = change.doc.data();
              if (candidateData) {
                addOrBufferCandidate(pc, candidateData);
              }
            }
          });
        },
        (err) => {
          console.warn("Call candidates listener notice:", err.message);
        }
      );
    }
  }, [facingMode, session.id, session.isIncoming, session.type, db, isFirebaseConfigured, session.startedAt, attachStreamsToElements]);

  // Lifecycles: dialing/ringing tones & Call duration timers
  useEffect(() => {
    if (session.status === 'dialing') {
      startAudioTone('dialing');
    } else if (session.status === 'ringing') {
      startAudioTone('ringing');
    } else if (session.status === 'connected' || isRemoteConnected) {
      stopAudioTone();
      wasConnectedRef.current = true;
      if (!durationTimerRef.current) {
        durationTimerRef.current = setInterval(() => {
          setCallDuration(prev => prev + 1);
        }, 1000);
      }
    } else {
      stopAudioTone();
    }
  }, [session.status, isRemoteConnected, startAudioTone, stopAudioTone]);

  // Main signaling listeners (Firestore snapshot + BroadcastChannel message handling)
  useEffect(() => {
    let isCancelled = false;

    // Initialize BroadcastChannel
    try {
      if (typeof BroadcastChannel !== 'undefined') {
        const channel = new BroadcastChannel(`zenoa_call_${session.id}`);
        broadcastChannelRef.current = channel;

        channel.onmessage = async (e) => {
          const msg = e.data;
          if (!msg || isCancelled) return;
          const pc = peerConnectionRef.current;

          if (msg.type === 'accept') {
            setIsRemoteConnected(true);
            wasConnectedRef.current = true;
            stopAudioTone();
            onAnswerCall();
          } else if (msg.type === 'offer' && session.isIncoming) {
            if (pc && !pc.currentRemoteDescription && !isSettingRemoteDescriptionRef.current) {
              try {
                isSettingRemoteDescriptionRef.current = true;
                await pc.setRemoteDescription(new RTCSessionDescription(msg.offer));
                await processPendingCandidates(pc);
                const answer = await pc.createAnswer();
                await pc.setLocalDescription(answer);
                isSettingRemoteDescriptionRef.current = false;
                if (broadcastChannelRef.current) {
                  broadcastChannelRef.current.postMessage({
                    type: 'answer',
                    answer: { type: answer.type, sdp: answer.sdp }
                  });
                }
              } catch (err) {
                isSettingRemoteDescriptionRef.current = false;
                console.warn("BC Offer handle notice:", err);
              }
            }
          } else if (msg.type === 'answer' && !session.isIncoming) {
            if (pc && !pc.currentRemoteDescription && !isSettingRemoteDescriptionRef.current) {
              try {
                isSettingRemoteDescriptionRef.current = true;
                await pc.setRemoteDescription(new RTCSessionDescription(msg.answer));
                await processPendingCandidates(pc);
                isSettingRemoteDescriptionRef.current = false;
                setIsRemoteConnected(true);
                wasConnectedRef.current = true;
                stopAudioTone();
              } catch (err) {
                isSettingRemoteDescriptionRef.current = false;
                console.warn("BC Answer handle notice:", err);
              }
            }
          } else if (msg.type === 'hangup' || msg.type === 'ended' || msg.type === 'decline' || msg.type === 'cancel') {
            handleCallEndedRemotely(msg.type === 'decline' ? 'declined' : 'ended');
          } else if (msg.type === 'ice-candidate') {
            const expectedRole = session.isIncoming ? 'caller' : 'callee';
            if (msg.senderRole === expectedRole && msg.candidate && pc) {
              addOrBufferCandidate(pc, msg.candidate);
            }
          }
        };
      }
    } catch (bcErr) {
      console.warn("BroadcastChannel support warning:", bcErr);
    }

    // Initialize Firestore call document listener
    const callDocRef = (isFirebaseConfigured && db && session.id) ? doc(db, 'calls', session.id) : null;
    if (callDocRef) {
      unsubscribeCallDocRef.current = onSnapshot(
        callDocRef,
        async (snap) => {
          if (!snap.exists() || isCancelled) return;
          const data = snap.data();
          const pc = peerConnectionRef.current;

          // Remote hang up, decline, timeout, or cancellation
          const terminalStatuses = ['ended', 'declined', 'cancelled', 'unanswered', 'missed', 'rejected', 'timeout'];
          if (terminalStatuses.includes(data.status) || (data.end_reason && terminalStatuses.includes(data.end_reason))) {
            handleCallEndedRemotely(data.status || data.end_reason || 'ended');
            return;
          }

          // Caller detects callee answered
          if (!session.isIncoming && data.status === 'connected') {
            setIsRemoteConnected(true);
            wasConnectedRef.current = true;
            stopAudioTone();
            onAnswerCall();
          }

          // Callee receives caller's offer
          const isAccepted = wasConnectedRef.current || isRemoteConnected || sessionRef.current.status === 'connected';
          if (session.isIncoming && data.offer && isAccepted) {
            if (pc && !pc.currentRemoteDescription && !isSettingRemoteDescriptionRef.current) {
              try {
                isSettingRemoteDescriptionRef.current = true;
                await pc.setRemoteDescription(new RTCSessionDescription(data.offer));
                await processPendingCandidates(pc);

                const answer = await pc.createAnswer();
                await pc.setLocalDescription(answer);

                await setDoc(callDocRef, {
                  answer: { type: answer.type, sdp: answer.sdp },
                  status: 'connected',
                  answered_at: Date.now()
                }, { merge: true });
                isSettingRemoteDescriptionRef.current = false;
                setIsRemoteConnected(true);
                wasConnectedRef.current = true;

                if (broadcastChannelRef.current) {
                  broadcastChannelRef.current.postMessage({
                    type: 'answer',
                    answer: { type: answer.type, sdp: answer.sdp }
                  });
                }
              } catch (e) {
                isSettingRemoteDescriptionRef.current = false;
                console.warn("Offer handling notice:", e);
              }
            } else if (!isPeerConnectionInitializedRef.current) {
              initWebRTC();
            }
          }

          // Caller receives callee's answer
          if (!session.isIncoming && data.answer && pc && !pc.currentRemoteDescription && !isSettingRemoteDescriptionRef.current) {
            try {
              isSettingRemoteDescriptionRef.current = true;
              await pc.setRemoteDescription(new RTCSessionDescription(data.answer));
              await processPendingCandidates(pc);
              isSettingRemoteDescriptionRef.current = false;
              setIsRemoteConnected(true);
              wasConnectedRef.current = true;
              stopAudioTone();
            } catch (e) {
              isSettingRemoteDescriptionRef.current = false;
              console.warn("Answer handling notice:", e);
            }
          }
        },
        (err) => {
          console.warn("Call snapshot listener notice:", err.message);
        }
      );
    }

    // Trigger immediate WebRTC signaling for the Caller
    if (!session.isIncoming) {
      console.log("Caller triggering WebRTC initialization immediately...");
      initWebRTC();
    }

    return () => {
      isCancelled = true;
    };
  }, [session.id, session.isIncoming, initWebRTC]);

  // Callee WebRTC Trigger
  useEffect(() => {
    if (session.isIncoming && (session.status === 'connected' || wasConnectedRef.current) && !isPeerConnectionInitializedRef.current) {
      console.log("Callee accepted call, starting peer connection...");
      initWebRTC();
    }
  }, [session.status, session.isIncoming, initWebRTC]);

  // Clean up all resources strictly when component unmounts
  useEffect(() => {
    return () => {
      console.log("CallModal unmounted. Destroying WebRTC and active listeners...");
      cleanupCall();
    };
  }, [cleanupCall]);

  // Format Duration string MM:SS or HH:MM:SS
  const formatTime = (secs: number) => {
    const h = Math.floor(secs / 3600);
    const m = Math.floor((secs % 3600) / 60);
    const s = secs % 60;
    if (h > 0) {
      return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
    }
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  // Helper when remote ends call
  const handleCallEndedRemotely = (remoteStatus: string) => {
    const endTimeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const finalDuration = callDurationRef.current;
    const wasConnected = wasConnectedRef.current || isRemoteConnected || session.status === 'connected';
    
    let finalStatus: 'answered' | 'missed' | 'unanswered' | 'declined';
    if (wasConnected) {
      finalStatus = 'answered';
    } else {
      finalStatus = session.isIncoming ? 'missed' : (remoteStatus === 'declined' ? 'declined' : 'unanswered');
    }

    cleanupCall();
    onEndCall({
      callId: session.id,
      callType: session.type,
      status: finalStatus,
      startTime: startTimeStrRef.current,
      endTime: endTimeStr,
      durationSeconds: finalDuration,
      durationFormatted: formatTime(finalDuration)
    });
  };

  // Ring timeout (45 seconds limit) - Automatically cut call on both sides if unanswered
  const handleTimeoutCut = useCallback(async () => {
    const endTimeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const wasConnected = wasConnectedRef.current || isRemoteConnected || session.status === 'connected';
    if (wasConnected) return;

    if (broadcastChannelRef.current) {
      broadcastChannelRef.current.postMessage({ type: 'hangup', reason: 'timeout' });
      broadcastChannelRef.current.postMessage({ type: 'ended', reason: 'timeout' });
    }

    cleanupCall();

    const finalStatus: 'missed' | 'unanswered' = session.isIncoming ? 'missed' : 'unanswered';

    if (isFirebaseConfigured && db && session.id) {
      try {
        await setDoc(doc(db, 'calls', session.id), {
          status: 'ended',
          end_reason: 'timeout',
          call_status: finalStatus,
          ended_at: Date.now(),
          duration: 0,
          duration_seconds: 0,
          duration_formatted: '00:00',
          end_time_str: endTimeStr
        }, { merge: true });
      } catch (e) {
        console.warn("Firestore timeout call termination notice:", e);
      }
    }

    onEndCall({
      callId: session.id,
      callType: session.type,
      status: finalStatus,
      startTime: startTimeStrRef.current,
      endTime: endTimeStr,
      durationSeconds: 0,
      durationFormatted: '00:00'
    });
  }, [cleanupCall, db, isFirebaseConfigured, isRemoteConnected, onEndCall, session.id, session.isIncoming, session.status, session.type]);

  // 45-Second Ring Limit Auto-Cut Timer: Automatically ends call on both sides if unanswered within 45s
  useEffect(() => {
    if (isRemoteConnected || session.status === 'connected') return;

    const RING_TIMEOUT_MS = 45000;
    const now = Date.now();
    const startTime = session.startedAt || now;
    const elapsed = Math.max(0, now - startTime);
    const remaining = Math.max(500, RING_TIMEOUT_MS - elapsed);

    const timer = setTimeout(() => {
      handleTimeoutCut();
    }, remaining);

    const interval = setInterval(() => {
      const nowTick = Date.now();
      const elapsedTick = Math.max(0, nowTick - startTime);
      const remainingSecs = Math.max(0, Math.ceil((RING_TIMEOUT_MS - elapsedTick) / 1000));
      setRingCountdown(remainingSecs);
    }, 1000);

    return () => {
      clearTimeout(timer);
      clearInterval(interval);
    };
  }, [isRemoteConnected, session.status, session.startedAt, handleTimeoutCut]);

  // User manually clicks Hang Up
  const handleHangUp = async () => {
    const endTimeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const finalDuration = callDurationRef.current;
    const wasConnected = wasConnectedRef.current || isRemoteConnected || session.status === 'connected';
    
    let finalStatus: 'answered' | 'missed' | 'unanswered' | 'declined';
    if (wasConnected) {
      finalStatus = 'answered';
    } else {
      finalStatus = session.isIncoming ? 'declined' : 'unanswered';
    }

    if (broadcastChannelRef.current) {
      broadcastChannelRef.current.postMessage({ type: 'hangup', reason: wasConnected ? 'ended' : 'cancelled' });
      broadcastChannelRef.current.postMessage({ type: 'ended', reason: wasConnected ? 'ended' : 'cancelled' });
    }

    cleanupCall();

    if (isFirebaseConfigured && db && session.id) {
      try {
        await setDoc(doc(db, 'calls', session.id), {
          status: 'ended',
          end_reason: wasConnected ? 'answered' : (session.isIncoming ? 'declined' : 'cancelled'),
          cancelled_by_caller: !session.isIncoming && !wasConnected,
          call_status: finalStatus,
          ended_at: Date.now(),
          duration: finalDuration,
          duration_seconds: finalDuration,
          duration_formatted: formatTime(finalDuration),
          end_time_str: endTimeStr
        }, { merge: true });
      } catch (e) {
        console.warn("Firestore call termination update notice:", e);
      }
    }

    onEndCall({
      callId: session.id,
      callType: session.type,
      status: finalStatus,
      startTime: startTimeStrRef.current,
      endTime: endTimeStr,
      durationSeconds: finalDuration,
      durationFormatted: formatTime(finalDuration)
    });
  };

  // Callee clicks "Answer"
  const handleAcceptIncoming = async () => {
    stopAudioTone();
    wasConnectedRef.current = true;
    setIsRemoteConnected(true);

    if (!isPeerConnectionInitializedRef.current) {
      initWebRTC();
    }

    if (isFirebaseConfigured && db && session.id) {
      try {
        await setDoc(doc(db, 'calls', session.id), {
          status: 'connected',
          answered_at: Date.now()
        }, { merge: true });
      } catch (e) {
        console.warn("Firestore accept call update notice:", e);
      }
    }
    if (broadcastChannelRef.current) {
      broadcastChannelRef.current.postMessage({ type: 'accept' });
    }
    onAnswerCall();
  };

  // Callee clicks "Decline"
  const handleDeclineIncoming = async () => {
    const endTimeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    cleanupCall();

    if (broadcastChannelRef.current) {
      broadcastChannelRef.current.postMessage({ type: 'decline' });
    }

    if (isFirebaseConfigured && db && session.id) {
      try {
        await setDoc(doc(db, 'calls', session.id), {
          status: 'declined',
          ended_at: Date.now(),
          duration: 0,
          duration_seconds: 0,
          duration_formatted: '00:00',
          end_time_str: endTimeStr
        }, { merge: true });
      } catch (e) {
        console.warn("Firestore decline call update notice:", e);
      }
    }

    onEndCall({
      callId: session.id,
      callType: session.type,
      status: 'missed',
      startTime: startTimeStrRef.current,
      endTime: endTimeStr,
      durationSeconds: 0,
      durationFormatted: '00:00'
    });
  };

  // Toggle Microphone
  const handleToggleMute = () => {
    if (localStreamRef.current) {
      const audioTracks = localStreamRef.current.getAudioTracks();
      if (audioTracks.length > 0) {
        const nextState = !isMuted;
        audioTracks.forEach(t => { t.enabled = !nextState; });
        setIsMuted(nextState);
      }
    }
  };

  // Toggle Camera
  const handleToggleVideo = () => {
    if (localStreamRef.current && session.type === 'video') {
      const videoTracks = localStreamRef.current.getVideoTracks();
      if (videoTracks.length > 0) {
        const nextState = !isVideoOff;
        videoTracks.forEach(t => { t.enabled = !nextState; });
        setIsVideoOff(nextState);
      }
    }
  };

  // Switch Camera: Front ('user') <-> Rear ('environment')
  const handleSwitchCamera = async () => {
    if (session.type !== 'video') return;
    const nextMode = facingMode === 'user' ? 'environment' : 'user';
    setFacingMode(nextMode);

    try {
      if (localStreamRef.current) {
        localStreamRef.current.getVideoTracks().forEach(t => t.stop());
      }

      const newStream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: nextMode,
          width: { ideal: 1280, min: 640 },
          height: { ideal: 720, min: 480 },
          frameRate: { ideal: 30, min: 20 }
        }
      });

      const newVideoTrack = newStream.getVideoTracks()[0];
      if (!newVideoTrack) return;

      if (localStreamRef.current) {
        localStreamRef.current.getVideoTracks().forEach(t => localStreamRef.current!.removeTrack(t));
        localStreamRef.current.addTrack(newVideoTrack);
      }

      attachStreamsToElements();

      if (peerConnectionRef.current) {
        const senders = peerConnectionRef.current.getSenders();
        const videoSender = senders.find(s => s.track && s.track.kind === 'video');
        if (videoSender) {
          await videoSender.replaceTrack(newVideoTrack);
        }
      }
    } catch (err) {
      console.warn("Camera switch notice:", err);
    }
  };

  // Avatar Renderer Helper - Professional Initials or User Photo (No cartoon emojis)
  const renderCallAvatar = (seed: string, initials: string, url?: string, sizeClass = 'h-28 w-28 text-3xl') => {
    if (url && url.trim().length > 5) {
      return (
        <img 
          src={url} 
          alt={initials || 'User Avatar'} 
          referrerPolicy="no-referrer"
          className={`${sizeClass} rounded-full object-cover border-4 border-white/20 shadow-2xl bg-neutral-900`} 
        />
      );
    }
    
    const raw = (initials || seed || 'User').trim();
    const cleanLetters = raw.replace(/[^a-zA-Z0-9]/g, '').slice(0, 2).toUpperCase() || 'U';

    const gradients = [
      'from-indigo-600 via-indigo-700 to-violet-800',
      'from-violet-600 via-purple-700 to-fuchsia-800',
      'from-rose-600 via-pink-700 to-red-800',
      'from-emerald-600 via-teal-700 to-cyan-800',
      'from-sky-600 via-blue-700 to-indigo-800'
    ];
    let hash = 0;
    for (let i = 0; i < raw.length; i++) hash += raw.charCodeAt(i);
    const grad = gradients[hash % gradients.length];

    return (
      <div className={`${sizeClass} rounded-full bg-gradient-to-tr ${grad} flex items-center justify-center font-black text-white border-4 border-white/20 shadow-2xl relative overflow-hidden select-none tracking-wider`}>
        <span>{cleanLetters}</span>
      </div>
    );
  };

  const isConnected = session.status === 'connected' || isRemoteConnected;

  return (
    <>
      {/* Remote Audio output (handles high fidelity sound for both Voice & Video calls, ALWAYS mounted) */}
      <audio 
        ref={remoteAudioRef} 
        autoPlay 
        playsInline 
        muted={false}
        className="opacity-0 pointer-events-none absolute w-px h-px" 
      />

      {isMinimized ? (
        /* Floating Picture-in-Picture Mini Window (Freely Draggable Anywhere) */
        <div id="call_mini_window_wrapper" className="fixed inset-0 pointer-events-none z-[9999] select-none">
          {session.type === 'video' ? (
            <motion.div 
              key="call-mini-window-video"
              drag
              dragMomentum={false}
              dragElastic={0.04}
              layout={false}
              style={{ willChange: 'transform' }}
              initial={{ scale: 0.85, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.85, opacity: 0 }}
              className="pointer-events-auto absolute bottom-5 right-5 sm:bottom-8 sm:right-8 w-36 h-52 sm:w-40 sm:h-56 rounded-2xl overflow-hidden shadow-2xl border-2 border-white/30 bg-neutral-950 flex flex-col justify-between p-2 relative touch-none cursor-grab active:cursor-grabbing group"
            >
              {/* Remote Video Feed or Avatar if remote video off */}
              {isRemoteConnected && remoteStreamRef.current && remoteStreamRef.current.getVideoTracks().length > 0 ? (
                <video
                  ref={miniVideoElementRef}
                  autoPlay
                  playsInline
                  muted={false}
                  className="absolute inset-0 w-full h-full object-cover cursor-pointer"
                  onClick={() => setIsMinimized(false)}
                />
              ) : (
                <div 
                  className="absolute inset-0 bg-neutral-900 flex flex-col items-center justify-center p-3 cursor-pointer"
                  onClick={() => setIsMinimized(false)}
                >
                  <div className="relative">
                    {renderCallAvatar(session.partnerAvatarSeed, (session.partnerName?.[0] || "C"), session.partnerAvatarUrl, 'h-14 w-14 text-lg')}
                  </div>
                  <p className="mt-2 text-xs font-bold text-white text-center truncate max-w-full">
                    {session.partnerName}
                  </p>
                </div>
              )}

              {/* Vignette Overlay */}
              <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-transparent to-black/80 pointer-events-none" />

              {/* Top Row: Live Timer & Maximize */}
              <div className="relative z-10 flex items-center justify-between w-full">
                <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-black/70 backdrop-blur-md border border-white/15 text-[9px] text-white font-mono shadow-xs">
                  <span className={`h-1.5 w-1.5 rounded-full ${isConnected ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
                  <span>{isConnected ? formatTime(callDuration) : 'Calling...'}</span>
                </div>
                <button
                  onClick={(e) => { e.stopPropagation(); setIsMinimized(false); }}
                  className="p-1 rounded-full bg-black/60 hover:bg-black/80 text-white backdrop-blur-md border border-white/15 transition-transform active:scale-90 cursor-pointer shadow-md"
                  title="Maximize call"
                  aria-label="Maximize call"
                >
                  <Maximize2 className="h-3 w-3" />
                </button>
              </div>

              {/* Center Tap Area to expand */}
              <div 
                className="relative z-10 flex-1 flex flex-col items-center justify-center cursor-pointer"
                onClick={() => setIsMinimized(false)}
              />

              {/* Bottom Controls */}
              <div className="relative z-10 flex items-center justify-center gap-1.5 pt-1">
                <button
                  onClick={(e) => { e.stopPropagation(); handleToggleMute(); }}
                  className={`p-1.5 rounded-full backdrop-blur-md text-white border transition-all cursor-pointer ${
                    isMuted ? 'bg-rose-500/80 border-rose-400/50' : 'bg-white/20 border-white/20 hover:bg-white/30'
                  }`}
                  title={isMuted ? "Unmute" : "Mute"}
                >
                  {isMuted ? <MicOff className="h-3 w-3" /> : <Mic className="h-3 w-3" />}
                </button>
                <button
                  onClick={(e) => { e.stopPropagation(); handleSwitchCamera(); }}
                  className="p-1.5 rounded-full bg-white/20 hover:bg-white/30 border border-white/20 backdrop-blur-md text-white transition-all cursor-pointer"
                  title="Switch Camera"
                >
                  <SwitchCamera className="h-3 w-3" />
                </button>
                <button
                  onClick={(e) => { e.stopPropagation(); handleHangUp(); }}
                  className="p-1.5 rounded-full bg-rose-600 hover:bg-rose-700 text-white shadow-lg transition-transform active:scale-90 cursor-pointer"
                  title="End Call"
                >
                  <PhoneOff className="h-3 w-3" />
                </button>
              </div>
            </motion.div>
          ) : (
            <motion.div 
              key="call-mini-window-voice"
              drag
              dragMomentum={false}
              dragElastic={0.04}
              layout={false}
              style={{ willChange: 'transform' }}
              initial={{ scale: 0.85, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.85, opacity: 0 }}
              className="pointer-events-auto absolute bottom-5 right-5 sm:bottom-8 sm:right-8 w-64 p-2.5 rounded-2xl bg-neutral-900/95 border border-white/20 backdrop-blur-xl shadow-2xl flex items-center justify-between gap-2.5 text-white touch-none cursor-grab active:cursor-grabbing"
            >
              <div 
                className="flex items-center gap-2 min-w-0 flex-1 cursor-pointer"
                onClick={() => setIsMinimized(false)}
              >
                <div className="relative shrink-0">
                  {renderCallAvatar(session.partnerAvatarSeed, (session.partnerName?.[0] || "C"), session.partnerAvatarUrl, 'h-9 w-9 text-xs')}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-bold text-white truncate">{session.partnerName}</p>
                  <div className="flex items-center gap-1 text-[10px] font-mono text-neutral-300">
                    <span className={`h-1.5 w-1.5 rounded-full ${isConnected ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
                    <span>{isConnected ? formatTime(callDuration) : 'Calling...'}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-1 shrink-0">
                <button
                  onClick={(e) => { e.stopPropagation(); handleToggleMute(); }}
                  className={`p-1.5 rounded-full text-white transition-all cursor-pointer ${
                    isMuted ? 'bg-rose-500/80' : 'bg-white/15 hover:bg-white/25'
                  }`}
                  title={isMuted ? "Unmute" : "Mute"}
                >
                  {isMuted ? <MicOff className="h-3 w-3" /> : <Mic className="h-3 w-3" />}
                </button>
                <button
                  onClick={(e) => { e.stopPropagation(); handleHangUp(); }}
                  className="p-1.5 rounded-full bg-rose-600 hover:bg-rose-700 text-white shadow-md transition-transform active:scale-90 cursor-pointer"
                  title="End call"
                >
                  <PhoneOff className="h-3 w-3" />
                </button>
                <button
                  onClick={(e) => { e.stopPropagation(); setIsMinimized(false); }}
                  className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition-transform active:scale-90 cursor-pointer"
                  title="Maximize call"
                  aria-label="Maximize call"
                >
                  <Maximize2 className="h-3 w-3" />
                </button>
              </div>
            </motion.div>
          )}
        </div>
      ) : (
        /* Full Screen Call UI */
        <div 
          id="call_modal_root"
          className="fixed inset-0 z-[9999] bg-neutral-950 text-white flex flex-col justify-between overflow-hidden select-none font-sans"
        >
          {/* Prominent Zenoa Top Header Bar */}
          <div className="p-4 sm:p-6 flex items-center justify-between bg-gradient-to-b from-black/90 via-black/50 to-transparent z-50">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setIsMinimized(true)}
                className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white backdrop-blur-md border border-white/10 transition-all active:scale-95 cursor-pointer shadow-md"
                title="Minimize call"
                aria-label="Minimize"
              >
                <ChevronDown className="h-5 w-5" />
              </button>
              <div className="flex items-center gap-2">
                <span className="text-xl sm:text-2xl font-black tracking-widest text-white uppercase font-sans drop-shadow-md">
                  Zenoa
                </span>
                <span className="text-[10px] uppercase font-bold tracking-widest px-2 py-0.5 rounded-full bg-white/10 text-neutral-300 backdrop-blur-sm border border-white/10">
                  {session.type === 'video' ? 'HD Video' : 'HD Voice'}
                </span>
              </div>
            </div>
        
        <AnimatePresence mode="wait">
          {isConnected ? (
            <motion.div 
              key="connected-badge"
              initial={{ opacity: 0, scale: 0.8, y: -5 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.8 }}
              className="flex items-center gap-2 px-4 py-1.5 bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 font-bold font-mono text-xs sm:text-sm rounded-full backdrop-blur-md shadow-[0_0_15px_rgba(16,185,129,0.2)]"
            >
              <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>{formatTime(callDuration)}</span>
            </motion.div>
          ) : (
            <motion.div 
              key="connecting-badge"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              className="flex items-center gap-1.5 px-3.5 py-1.5 bg-amber-500/15 border border-amber-500/25 text-amber-400 font-semibold text-xs rounded-full backdrop-blur-md shadow-[0_0_15px_rgba(245,158,11,0.15)] animate-pulse"
            >
              <Radio className="h-3.5 w-3.5 animate-spin" />
              <span>{session.isIncoming ? 'Incoming...' : 'Connecting...'}</span>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Main Stream / Center Area */}
      <div className="flex-1 relative flex flex-col items-center justify-center overflow-hidden">
        {hasMediaError && (
          <div className="absolute top-6 max-w-sm mx-4 bg-rose-500/20 border border-rose-500/30 rounded-2xl p-4 text-center z-50 flex flex-col items-center gap-2 backdrop-blur-md">
            <AlertCircle className="h-6 w-6 text-rose-400" />
            <p className="text-xs font-bold text-rose-300">Media Device Notice</p>
            <p className="text-[11px] text-neutral-200 leading-relaxed">{hasMediaError}</p>
          </div>
        )}

        {/* Video Mode Layout */}
        {session.type === 'video' ? (
          <div className="absolute inset-0 w-full h-full flex items-center justify-center bg-neutral-950">
            
            {/* 1. Main View (Full Screen Video Feed: User's camera active immediately in background before connection) */}
            <div className="absolute inset-0 w-full h-full bg-neutral-900 flex items-center justify-center">
              <video 
                ref={mainVideoElementRef} 
                autoPlay 
                playsInline 
                muted={!isConnected || isSwapped} 
                className="w-full h-full object-cover"
                style={{ transform: (!isConnected || (isSwapped && facingMode === 'user')) ? 'scaleX(-1)' : 'none' }}
              />

              {/* Frosted Calling Overlay (Live camera feed remains active & visible behind this) */}
              <AnimatePresence>
                {!isConnected && (
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0, scale: 0.95, transition: { duration: 0.3 } }}
                    className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/20 to-black/75 flex flex-col items-center justify-center p-6 z-20 pointer-events-none"
                  >
                    <motion.div 
                      initial={{ scale: 0.9, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      className="flex flex-col items-center space-y-4 p-6 rounded-3xl bg-black/40 backdrop-blur-md border border-white/15 shadow-2xl text-center max-w-xs"
                    >
                      <div className="relative flex items-center justify-center">
                        <motion.div
                          animate={{ scale: [1, 1.25, 1], opacity: [0.6, 0.2, 0.6] }}
                          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                          className="absolute -inset-2 rounded-full border-2 border-emerald-400/50 shadow-[0_0_20px_rgba(52,211,153,0.3)]"
                        />
                        {renderCallAvatar(session.partnerAvatarSeed, (session.partnerName?.[0] || "C"), session.partnerAvatarUrl, 'h-24 w-24 text-3xl')}
                      </div>

                      <div className="space-y-1">
                        <h3 className="text-xl font-bold tracking-tight text-white drop-shadow-md">{session.partnerName}</h3>
                        <div className="pt-1">
                          <span className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-white/15 border border-white/20 text-xs font-semibold text-white/90 backdrop-blur-md shadow-xs animate-pulse">
                            <Radio className="h-3.5 w-3.5 animate-spin" />
                            <span>{session.isIncoming ? 'Incoming Video Call...' : 'Calling...'}</span>
                          </span>
                        </div>
                      </div>
                    </motion.div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* 2. Floating Picture-in-Picture Frame: ONLY appears once connected with smooth spring animation */}
            <AnimatePresence>
              {isConnected && (!isVideoOff || isSwapped) && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.5, y: 20 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.5, y: 20 }}
                  transition={{ type: "spring", damping: 24, stiffness: 300 }}
                  onClick={() => setIsSwapped(!isSwapped)}
                  className="absolute top-4 right-4 w-28 h-40 sm:w-36 sm:h-52 rounded-2xl overflow-hidden border-2 border-white/25 shadow-2xl bg-neutral-900 z-40 cursor-pointer hover:border-white/50 transition-all active:scale-95"
                  title="Tap to swap main and mini camera view"
                >
                  <video 
                    ref={pipVideoElementRef} 
                    autoPlay 
                    muted={!isSwapped} // mute local camera when in PiP
                    playsInline 
                    className="w-full h-full object-cover pointer-events-none" 
                    style={{ transform: !isSwapped && facingMode === 'user' ? 'scaleX(-1)' : 'none' }}
                  />
                  <div className="absolute bottom-1.5 left-1.5 px-2 py-0.5 rounded-md bg-black/60 backdrop-blur-sm text-[9px] font-bold text-white/90">
                    {isSwapped ? 'Remote' : 'You'}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ) : (
          /* Voice Mode Layout */
          <div className="flex flex-col items-center justify-center space-y-8 z-10 p-6 max-w-sm text-center">
            
            {/* Pulsing Avatar with Seamless Transition Ripples */}
            <div className="relative flex items-center justify-center">
              <AnimatePresence mode="wait">
                {!isConnected ? (
                  <motion.div 
                    key="voice-connecting-ripples"
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 1.2, transition: { duration: 0.4 } }}
                    className="absolute inset-0 flex items-center justify-center pointer-events-none"
                  >
                    {/* Ambient Glow */}
                    <div className="absolute w-52 h-52 rounded-full bg-gradient-to-r from-indigo-600/20 via-purple-600/20 to-pink-600/20 blur-2xl animate-pulse" />

                    {/* Ripple Ring 1 */}
                    <motion.div
                      animate={{ scale: [1, 1.85, 2.4], opacity: [0.75, 0.35, 0] }}
                      transition={{ duration: 2.4, repeat: Infinity, ease: "easeOut", delay: 0 }}
                      className="absolute inset-0 rounded-full border border-indigo-500/40 bg-indigo-500/10 shadow-[0_0_20px_rgba(99,102,241,0.2)]"
                    />

                    {/* Ripple Ring 2 */}
                    <motion.div
                      animate={{ scale: [1, 1.85, 2.4], opacity: [0.75, 0.35, 0] }}
                      transition={{ duration: 2.4, repeat: Infinity, ease: "easeOut", delay: 0.8 }}
                      className="absolute inset-0 rounded-full border border-violet-500/35 bg-violet-500/10 shadow-[0_0_25px_rgba(139,92,246,0.15)]"
                    />

                    {/* Ripple Ring 3 */}
                    <motion.div
                      animate={{ scale: [1, 1.85, 2.4], opacity: [0.75, 0.35, 0] }}
                      transition={{ duration: 2.4, repeat: Infinity, ease: "easeOut", delay: 1.6 }}
                      className="absolute inset-0 rounded-full border border-pink-500/30 bg-pink-500/5 shadow-[0_0_30px_rgba(236,72,153,0.1)]"
                    />

                    {/* Rotating Dashed Radar Orbit */}
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 7, repeat: Infinity, ease: "linear" }}
                      className="absolute -inset-4 rounded-full border border-dashed border-indigo-400/30"
                    />
                  </motion.div>
                ) : (
                  <motion.div
                    key="voice-connected-halo"
                    initial={{ opacity: 0, scale: 0.7 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ type: 'spring', stiffness: 300, damping: 20 }}
                    className="absolute inset-0 flex items-center justify-center pointer-events-none"
                  >
                    {/* Connected Ambient Glow */}
                    <div className="absolute w-48 h-48 rounded-full bg-emerald-500/20 blur-2xl animate-pulse" />
                    
                    {/* Breathing Emerald Ring */}
                    <motion.div
                      animate={{ scale: [1, 1.35, 1], opacity: [0.3, 0.65, 0.3] }}
                      transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                      className="absolute inset-0 rounded-full border-2 border-emerald-500/30 bg-emerald-500/10 shadow-[0_0_35px_rgba(16,185,129,0.25)]"
                    />
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Avatar Center */}
              <motion.div 
                animate={isConnected ? { scale: [1, 1.03, 1] } : { scale: 1 }}
                transition={{ duration: 2.5, repeat: isConnected ? Infinity : 0, ease: 'easeInOut' }}
                className="relative z-10"
              >
                {renderCallAvatar(session.partnerAvatarSeed, (session.partnerName?.[0] || "C"), session.partnerAvatarUrl, 'h-32 w-32 sm:h-36 sm:w-36 text-4xl')}
              </motion.div>
            </div>

            {/* Details (Partner Name ONLY, no username) */}
            <div className="space-y-2">
              <h2 className="text-2xl font-black tracking-wide">{session.partnerName}</h2>
              
              <div className="pt-2">
                <AnimatePresence mode="wait">
                  {!isConnected ? (
                    <motion.div
                      key="status-connecting"
                      initial={{ opacity: 0, y: 5 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -5 }}
                      className="flex items-center justify-center"
                    >
                      {session.status === 'dialing' && (
                        <span className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-indigo-500/15 border border-indigo-500/30 text-xs font-bold text-indigo-300 animate-pulse shadow-[0_0_15px_rgba(99,102,241,0.2)]">
                          <Radio className="h-3.5 w-3.5 animate-spin" />
                          <span>Calling... {ringCountdown > 0 ? `${ringCountdown}s` : ''}</span>
                        </span>
                      )}
                      {session.status === 'ringing' && (
                        <span className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-xs font-bold text-emerald-300 animate-pulse shadow-[0_0_15px_rgba(16,185,129,0.2)]">
                          <Radio className="h-3.5 w-3.5 animate-spin" />
                          <span>Ringing... {ringCountdown > 0 ? `${ringCountdown}s` : ''}</span>
                        </span>
                      )}
                      {session.status !== 'dialing' && session.status !== 'ringing' && (
                        <span className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-xs font-bold text-amber-300 animate-pulse shadow-[0_0_15px_rgba(245,158,11,0.2)]">
                          <Radio className="h-3.5 w-3.5 animate-spin" />
                          <span>Connecting stream...</span>
                        </span>
                      )}
                    </motion.div>
                  ) : (
                    <motion.div
                      key="status-connected"
                      initial={{ opacity: 0, scale: 0.85 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ type: 'spring', stiffness: 350, damping: 22 }}
                      className="flex items-center justify-center gap-1.5 text-xs font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/25 px-4 py-1.5 rounded-full backdrop-blur-md shadow-[0_0_20px_rgba(16,185,129,0.2)]"
                    >
                      <span className="h-2 w-2 rounded-full bg-emerald-400 animate-ping mr-1" />
                      <span>Connected • Encrypted HD Voice</span>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>

            {/* Real Audio Waveform Visualizer for Speaking Activity */}
            {isConnected && (
              <div className="space-y-2">
                <div className="flex items-center gap-1.5 h-12 w-64 justify-center bg-neutral-900/60 border border-white/10 rounded-2xl px-6 backdrop-blur-md">
                  {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14].map((i) => {
                    const factor = Math.sin((i / 14) * Math.PI);
                    const activeVol = Math.max(micVolume, remoteAudioVolume);
                    const dynamicHeight = Math.max(8, (activeVol * factor * 0.8) + (activeVol > 5 ? Math.random() * 6 : 0));
                    return (
                      <div 
                        key={i} 
                        className="w-1.5 rounded-full bg-gradient-to-t from-emerald-500 to-indigo-400 transition-all duration-75"
                        style={{ height: `${isMuted && micVolume === 0 ? 4 : dynamicHeight}px` }}
                      />
                    );
                  })}
                </div>
                <p className="text-[10px] text-neutral-400 font-medium flex items-center justify-center gap-1">
                  <Activity className="h-3 w-3 text-emerald-400" />
                  <span>Real-time voice stream active</span>
                </p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Bottom Command Center Control Bar */}
      <div className="p-6 sm:p-8 bg-gradient-to-t from-black via-black/80 to-transparent z-50 flex flex-col items-center">
        
        {/* Incoming Call Dialog Controls */}
        {session.isIncoming && !isConnected ? (
          <div className="flex flex-col items-center gap-4 animate-bounce">
            <div className="flex items-center gap-8">
              {/* Decline Button */}
              <button 
                id="btn_decline_call"
                onClick={handleDeclineIncoming}
                className="p-5 bg-rose-600 hover:bg-rose-700 active:scale-95 text-white rounded-full transition-all shadow-xl shadow-rose-600/30 cursor-pointer"
                title="Decline Call"
              >
                <PhoneOff className="h-7 w-7" />
              </button>

              {/* Accept Button */}
              <button 
                id="btn_accept_call"
                onClick={handleAcceptIncoming}
                className="p-5 bg-emerald-500 hover:bg-emerald-600 active:scale-95 text-white rounded-full transition-all shadow-xl shadow-emerald-500/30 cursor-pointer"
                title="Answer Call"
              >
                <Phone className="h-7 w-7" />
              </button>
            </div>
          </div>
        ) : (
          /* Ongoing / Dialing Call Control Bar */
          <div className="flex items-center gap-3 sm:gap-5 bg-neutral-900/90 border border-white/15 px-6 py-3.5 rounded-full backdrop-blur-2xl shadow-2xl">
            {/* Mute Mic button */}
            <button 
              id="btn_toggle_mute"
              onClick={handleToggleMute}
              className={`p-3.5 rounded-full transition-all cursor-pointer active:scale-90 ${isMuted ? 'bg-rose-600 text-white' : 'bg-neutral-800 text-neutral-200 hover:bg-neutral-700 hover:text-white'}`}
              title={isMuted ? 'Unmute microphone' : 'Mute microphone'}
            >
              {isMuted ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
            </button>

            {/* Video Toggle & Switch Camera (Video Mode Only) */}
            {session.type === 'video' && (
              <>
                <button 
                  id="btn_toggle_video"
                  onClick={handleToggleVideo}
                  className={`p-3.5 rounded-full transition-all cursor-pointer active:scale-90 ${isVideoOff ? 'bg-rose-600 text-white' : 'bg-neutral-800 text-neutral-200 hover:bg-neutral-700 hover:text-white'}`}
                  title={isVideoOff ? 'Turn Camera On' : 'Turn Camera Off'}
                >
                  {isVideoOff ? <VideoOff className="h-5 w-5" /> : <Video className="h-5 w-5" />}
                </button>
                <button 
                  id="btn_switch_camera"
                  onClick={handleSwitchCamera}
                  className="p-3.5 rounded-full transition-all cursor-pointer active:scale-90 bg-neutral-800 text-neutral-200 hover:bg-neutral-700 hover:text-white"
                  title="Switch Camera (Front/Back)"
                >
                  <SwitchCamera className="h-5 w-5" />
                </button>
              </>
            )}

            {/* Speaker / Hands-free Toggle */}
            <button 
              id="btn_toggle_speaker"
              onClick={() => setIsSpeakerOn(!isSpeakerOn)}
              className={`p-3.5 rounded-full transition-all cursor-pointer active:scale-90 ${isSpeakerOn ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30' : 'bg-neutral-800 text-neutral-200 hover:bg-neutral-700 hover:text-white'}`}
              title={isSpeakerOn ? 'Hands-Free (Speakerphone On - Tap for Earpiece)' : 'Earpiece Mode (Tap for Hands-Free Speakerphone)'}
            >
              {isSpeakerOn ? <Volume2 className="h-5 w-5" /> : <Volume1 className="h-5 w-5" />}
            </button>

            {/* Hang Up Button */}
            <button 
              id="btn_hangup_call"
              onClick={handleHangUp}
              className="p-3.5 bg-rose-600 hover:bg-rose-700 hover:scale-105 active:scale-95 text-white rounded-full transition-all shadow-lg shadow-rose-600/40 cursor-pointer ml-1"
              title="End Call"
            >
              <PhoneOff className="h-5 w-5" />
            </button>
          </div>
        )}
      </div>
    </div>
    )}
  </>
  );
};
