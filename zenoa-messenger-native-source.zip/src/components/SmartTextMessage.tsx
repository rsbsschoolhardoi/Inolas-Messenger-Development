import React, { useState } from 'react';
import { Copy, Check, ExternalLink, Code, ShieldCheck, ChevronDown, ChevronUp } from 'lucide-react';
import { AppleEmojiText } from './AppleEmojiText';

interface SmartTextMessageProps {
  text: string;
  isMe: boolean;
  isSentDark?: boolean;
  isReceivedDark?: boolean;
  isSenderServiceAccount?: boolean;
  onToast?: (msg: string) => void;
  maxTextLength?: number;
}

const EMOJI_CHECK_REGEX = /[\p{Extended_Pictographic}\p{Emoji_Presentation}\u{1f1e6}-\u{1f1ff}]/u;
const NON_EMOJI_REGEX = /^[a-zA-Z0-9.,!?:;'"_+\-=~`@#$%^&*()[\]{}|\\/<>]+$/;

/**
 * Checks if string contains only emojis (1-30 emojis), with or without spaces.
 */
export function isEmojiOnly(str: string): boolean {
  if (!str) return false;
  const trimmed = str.trim();
  if (!trimmed) return false;

  if (typeof Intl !== 'undefined' && (Intl as any).Segmenter) {
    const segmenter = new (Intl as any).Segmenter(undefined, { granularity: 'grapheme' });
    let count = 0;
    for (const { segment } of segmenter.segment(trimmed)) {
      if (/^\s+$/.test(segment)) continue;
      if (EMOJI_CHECK_REGEX.test(segment) && !NON_EMOJI_REGEX.test(segment)) {
        count++;
      } else {
        return false;
      }
    }
    return count >= 1 && count <= 30;
  }

  const cleaned = trimmed.replace(/\s+/g, '');
  const emojiRegex = /^(\p{Extended_Pictographic}|\p{Emoji_Presentation}|\u200d|\ufe0f|\u20e3|[\u{1f3fb}-\u{1f3ff}]|[\u{1f1e6}-\u{1f1ff}]){1,30}$/u;
  return emojiRegex.test(cleaned) && !/[a-zA-Z0-9]/.test(cleaned);
}


/**
 * Smart Inline Formatter for Markdown, URLs, Mentions, and Formatting
 */
function parseInlineContent(
  text: string, 
  isMe: boolean, 
  isSentDark: boolean, 
  isReceivedDark: boolean,
  onToast?: (msg: string) => void
): React.ReactNode[] {
  if (!text) return [];

  const tokenRegex = /(\*\*[\s\S]+?\*\*|__[\s\S]+?__|~~[\s\S]+?~~|`[^`]+`|\*[^\*\n]+\*|_[^\_\n]+_|~[^~\n]+~|https?:\/\/[^\s<]+|www\.[^\s<]+|@[a-zA-Z0-9_]{3,30})/g;

  const parts = text.split(tokenRegex);

  return parts.map((part, idx) => {
    if (!part) return null;

    // 1. Inline Code
    if (part.startsWith('`') && part.endsWith('`') && part.length > 2) {
      const codeContent = part.slice(1, -1);
      return (
        <code 
          key={idx}
          className={`px-1.5 py-0.5 mx-0.5 rounded font-mono text-[11px] select-all border ${
            isMe 
              ? isSentDark ? 'bg-black/30 text-amber-200 border-white/20' : 'bg-black/10 text-amber-900 border-black/15'
              : isReceivedDark ? 'bg-white/10 text-amber-300 border-white/15' : 'bg-neutral-100 text-amber-800 border-neutral-300 dark:bg-neutral-800 dark:text-amber-300 dark:border-neutral-700'
          }`}
        >
          <AppleEmojiText text={codeContent} />
        </code>
      );
    }

    // 2. Bold (**text** or __text__)
    if ((part.startsWith('**') && part.endsWith('**') && part.length >= 4) ||
        (part.startsWith('__') && part.endsWith('__') && part.length >= 4)) {
      const boldContent = part.slice(2, -2);
      return (
        <strong key={idx} className="font-semibold tracking-tight">
          {parseInlineContent(boldContent, isMe, isSentDark, isReceivedDark, onToast)}
        </strong>
      );
    }

    // 3. Strikethrough (~~text~~ or ~text~)
    if ((part.startsWith('~~') && part.endsWith('~~') && part.length >= 4) ||
        (part.startsWith('~') && part.endsWith('~') && part.length >= 2)) {
      const strikeContent = part.startsWith('~~') ? part.slice(2, -2) : part.slice(1, -1);
      return (
        <del key={idx} className="line-through opacity-80">
          {parseInlineContent(strikeContent, isMe, isSentDark, isReceivedDark, onToast)}
        </del>
      );
    }

    // 4. Italic (*text* or _text_)
    if ((part.startsWith('*') && part.endsWith('*') && part.length >= 2) ||
        (part.startsWith('_') && part.endsWith('_') && part.length >= 2)) {
      const italicContent = part.slice(1, -1);
      return (
        <em key={idx} className="italic opacity-95">
          {parseInlineContent(italicContent, isMe, isSentDark, isReceivedDark, onToast)}
        </em>
      );
    }

    // 5. URL Link
    if (part.match(/^(https?:\/\/|www\.)/i)) {
      const href = part.startsWith('www.') ? `https://${part}` : part;
      return (
        <a
          key={idx}
          href={href}
          target="_blank"
          rel="noopener noreferrer"
          onClick={(e) => e.stopPropagation()}
          className={`inline-flex items-center gap-0.5 underline font-semibold break-all transition-opacity hover:opacity-80 ${
            isMe 
              ? isSentDark ? 'text-blue-200 underline' : 'text-blue-800 underline'
              : isReceivedDark ? 'text-blue-400 underline' : 'text-blue-600 dark:text-blue-400 underline'
          }`}
        >
          <span><AppleEmojiText text={part} /></span>
          <ExternalLink className="h-3 w-3 shrink-0 opacity-70" />
        </a>
      );
    }

    // 6. Username Mention (@username)
    if (part.startsWith('@') && part.length > 3) {
      return (
        <span
          key={idx}
          className={`font-bold px-1 py-0.2 mx-0.5 rounded text-[11px] ${
            isMe 
              ? 'bg-black/20 text-white' 
              : 'bg-indigo-100 text-indigo-700 dark:bg-indigo-900/40 dark:text-indigo-300'
          }`}
        >
          <AppleEmojiText text={part} />
        </span>
      );
    }

    // Plain text with Apple emoji rendering
    return <AppleEmojiText key={idx} text={part} />;
  });
}

/**
 * Code Block Component with Language Header and Copy Button
 */
const CodeBlock: React.FC<{ code: string; language?: string; onToast?: (msg: string) => void }> = ({
  code,
  language = 'code',
  onToast
}) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(code);
    setCopied(true);
    if (onToast) onToast('Code copied to clipboard!');
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="my-2 rounded-xl overflow-hidden border border-zinc-800 bg-zinc-950 text-zinc-100 shadow-lg text-left font-mono text-[11px] max-w-full">
      <div className="flex items-center justify-between px-3 py-1.5 bg-zinc-900 border-b border-zinc-800 text-[10px] text-zinc-400 font-sans select-none">
        <div className="flex items-center gap-1.5 font-bold uppercase tracking-wider text-zinc-300">
          <Code className="h-3.5 w-3.5 text-indigo-400" />
          <span>{language || 'code'}</span>
        </div>
        <button
          type="button"
          onClick={handleCopy}
          className="flex items-center gap-1 px-2 py-0.5 rounded bg-zinc-800 hover:bg-zinc-700 active:scale-95 text-zinc-200 font-semibold transition-all cursor-pointer"
        >
          {copied ? (
            <>
              <Check className="h-3 w-3 text-emerald-400" />
              <span className="text-emerald-400">Copied</span>
            </>
          ) : (
            <>
              <Copy className="h-3 w-3 text-zinc-400" />
              <span>Copy</span>
            </>
          )}
        </button>
      </div>

      <div className="p-3 overflow-x-auto max-h-80 leading-relaxed font-mono whitespace-pre select-all text-emerald-300 bg-zinc-950/90">
        <code>{code}</code>
      </div>
    </div>
  );
};

export const SmartTextMessage: React.FC<SmartTextMessageProps> = ({
  text,
  isMe,
  isSentDark = true,
  isReceivedDark = false,
  isSenderServiceAccount = false,
  onToast,
  maxTextLength = 280
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [copiedOtp, setCopiedOtp] = useState(false);

  if (!text) return null;

  // 1. Emoji-only rendering
  if (isEmojiOnly(text)) {
    const rawMatches = text.match(new RegExp('(\\p{Extended_Pictographic}|\\p{Emoji_Presentation}|[\\u{1f1e6}-\\u{1f1ff}]|[\\u{1f3fb}-\\u{1f3ff}]|[\\u200d\\ufe0f\\u20e3])+(\\ufe0f)?', 'gu')) || [];
    const emojiCount = rawMatches.length;
    const emojiSizeClass = emojiCount <= 1 
      ? 'w-14 h-14 sm:w-16 sm:h-16' 
      : emojiCount <= 4 
        ? 'w-10 h-10 sm:w-12 sm:h-12' 
        : 'w-8 h-8 sm:w-9 sm:h-9';

    return (
      <div className="py-1 animate-scale-in select-none flex items-center gap-2 flex-wrap">
        <AppleEmojiText text={text} emojiClassName={`inline-block ${emojiSizeClass} object-contain select-none pointer-events-none drop-shadow-xs`} />
      </div>
    );
  }

  // 2. Detect OTP / Verification Code
  const otpMatch = text.match(/\b(\d{4,8})\b/);
  const hasOtpContext = /otp|verification|passcode|security code|verify|login code|authorization code|auth code/i.test(text) || isSenderServiceAccount;
  const detectedOtp = (otpMatch && hasOtpContext) ? otpMatch[1] : null;

  // Detect Security Alert
  const isSecurityAlert = /SECURITY ALERT/i.test(text);

  const handleCopyOtp = (e: React.MouseEvent, code: string) => {
    e.stopPropagation();
    navigator.clipboard.writeText(code);
    setCopiedOtp(true);
    if (onToast) onToast(`Authentication Code ${code} copied to clipboard.`);
    setTimeout(() => setCopiedOtp(false), 2500);
  };

  const shouldTruncate = text.length > maxTextLength;
  const displayText = shouldTruncate && !isExpanded ? `${text.slice(0, maxTextLength)}...` : text;

  // 3. Parse Code Blocks
  const codeBlockRegex = /```([a-zA-Z0-9_-]*)\n([\s\S]*?)```/g;
  const blocks: { type: 'text' | 'code'; content: string; lang?: string }[] = [];

  let lastIdx = 0;
  let match: RegExpExecArray | null;

  while ((match = codeBlockRegex.exec(displayText)) !== null) {
    if (match.index > lastIdx) {
      blocks.push({ type: 'text', content: displayText.substring(lastIdx, match.index) });
    }
    blocks.push({ type: 'code', lang: match[1] || 'code', content: match[2].trim() });
    lastIdx = match.index + match[0].length;
  }

  if (lastIdx < displayText.length) {
    blocks.push({ type: 'text', content: displayText.substring(lastIdx) });
  }

  return (
    <div className="font-chat text-[13.5px] sm:text-sm font-[460] leading-[1.54] tracking-[-0.012em] break-words min-w-0 [overflow-wrap:anywhere] max-w-full space-y-1 select-text">
      {/* Smart Security Alert Banner */}
      {isSecurityAlert && (
        <div className={`my-1 px-3 py-1.5 rounded-lg border text-left ${
          isMe
            ? 'bg-black/20 border-white/20 text-white'
            : 'bg-slate-100/90 dark:bg-slate-900/80 border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200'
        }`}>
          <span className="text-[10px] font-semibold tracking-wide uppercase block text-slate-600 dark:text-slate-400">Security Notification</span>
        </div>
      )}

      {/* Smart OTP Copy Quick Action Banner */}
      {detectedOtp && (
        <div 
          onClick={(e) => handleCopyOtp(e, detectedOtp)}
          className={`my-1.5 px-3 py-2 rounded-xl border flex items-center justify-between gap-3 shadow-2xs transition-all cursor-pointer ${
            isMe
              ? 'bg-black/20 border-white/20 text-white hover:bg-black/30'
              : 'bg-slate-50/90 dark:bg-slate-900/90 border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800/80'
          }`}
        >
          <div className="text-left min-w-0">
            <span className="text-[10px] font-medium tracking-wide uppercase block text-slate-500 dark:text-slate-400">Authentication Code</span>
            <span className="font-mono font-bold text-sm tracking-widest block text-slate-900 dark:text-slate-100">{detectedOtp}</span>
          </div>

          <button
            type="button"
            className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 shrink-0 transition-transform active:scale-95 ${
              copiedOtp
                ? 'bg-slate-800 text-white dark:bg-slate-200 dark:text-slate-900'
                : 'bg-slate-900 hover:bg-slate-800 text-white dark:bg-slate-100 dark:hover:bg-white dark:text-slate-900'
            }`}
          >
            {copiedOtp ? (
              <>
                <Check className="h-3 w-3" />
                <span>Copied</span>
              </>
            ) : (
              <>
                <Copy className="h-3 w-3" />
                <span>Copy</span>
              </>
            )}
          </button>
        </div>
      )}

      {/* Render Text / Code Blocks */}
      {blocks.map((block, i) => {
        if (block.type === 'code') {
          return <CodeBlock key={i} code={block.content} language={block.lang} onToast={onToast} />;
        }

        const lines = block.content.split('\n');
        return (
          <div key={i} className="space-y-0.5">
            {lines.map((line, lineIdx) => {
              if (line.startsWith('> ')) {
                return (
                  <blockquote
                    key={lineIdx}
                    className={`pl-2 py-0.5 my-0.5 border-l-2 italic opacity-90 ${
                      isMe
                        ? 'border-white/40 bg-black/10'
                        : 'border-indigo-500/80 bg-indigo-500/10'
                    }`}
                  >
                    {parseInlineContent(line.slice(2), isMe, isSentDark, isReceivedDark, onToast)}
                  </blockquote>
                );
              }

              if (line.match(/^[\-\*]\s+/)) {
                return (
                  <div key={lineIdx} className="flex items-start gap-1.5 pl-1">
                    <span className="font-bold text-indigo-400">•</span>
                    <span>{parseInlineContent(line.replace(/^[\-\*]\s+/, ''), isMe, isSentDark, isReceivedDark, onToast)}</span>
                  </div>
                );
              }

              return (
                <div key={lineIdx} className="min-h-[1.25rem]">
                  {parseInlineContent(line, isMe, isSentDark, isReceivedDark, onToast)}
                </div>
              );
            })}
          </div>
        );
      })}

      {shouldTruncate && (
        <div className="pt-0.5">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setIsExpanded(!isExpanded);
            }}
            className={`font-bold text-[11px] underline cursor-pointer inline-flex items-center gap-0.5 ${
              isMe
                ? (isSentDark ? 'text-white underline hover:opacity-90' : 'text-slate-900 underline font-bold')
                : (isReceivedDark ? 'text-indigo-300 underline' : 'text-neutral-900 dark:text-neutral-100 underline')
            }`}
          >
            <span>{isExpanded ? 'See Less' : 'See More'}</span>
            {isExpanded ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
          </button>
        </div>
      )}
    </div>
  );
};
