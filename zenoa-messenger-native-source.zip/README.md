# Zenoa Sovereign Messenger — Native & Standalone Source Package
> Version 2.4.0 | Decoupled Real-Time Messaging, WebRTC Calling, Vault & Presence Engine

This package contains the complete, battle-tested source code of **Zenoa Messenger**, isolated and decoupled for native application development (React Native / Expo, Flutter, Android Jetpack Compose, iOS SwiftUI) or standalone web deployment.

---

## 📁 Package Architecture & Directory Structure

```
├── src/
│   ├── components/                 # Messenger UI Primitives & Modals
│   │   ├── MessageCard.tsx         # Universal message bubble (Text, Audio, Video, Poll, File, Location)
│   │   ├── AppleComposerInput.tsx  # iOS-style native composer with live formatting
│   │   ├── AppleEmoji.tsx          # High-performance Apple emoji rendering system
│   │   ├── VoiceNotePlayer.tsx     # Interactive audio waveform voice note player
│   │   ├── InlineVideoPlayer.tsx   # Hardware-accelerated inline video viewer
│   │   ├── MediaEditorModal.tsx    # In-app media cropper, caption editor & compression
│   │   ├── CallModal.tsx           # Real-time WebRTC Audio & Video Calling interface
│   │   ├── NewGroupModal.tsx       # Group chat creation with roles and avatars
│   │   ├── GroupDetailsModal.tsx   # Participant management, group admins & pinned media
│   │   ├── SettingsPage.tsx        # Security, Vault PIN, E2EE keys, Privacy controls
│   │   ├── ChatThemeModal.tsx      # Dynamic wallpaper & bubble styling engine
│   │   ├── DetailedProfilePage.tsx # User badges, following/followers, presence
│   │   └── AuthFlow.tsx            # Login, Signup, OTP Verification & Session Recovery
│   ├── utils/                      # Core Business Logic & Cryptography
│   │   ├── chatUtils.ts            # Normalized DM ID generation, ghost filters, participant hashing
│   │   ├── cryptoUtils.ts          # AES-256-GCM Envelope Encryption & Local Vault security
│   │   ├── dateUtils.ts            # Telegram/WhatsApp-grade timestamp dividers & relative times
│   │   ├── presenceUtils.ts        # Live online indicator, typing state & follower relations
│   │   ├── audioUtils.ts           # WebAudio API base64 audio recording & synthetic waveforms
│   │   ├── storageManager.ts       # IndexedDB & LocalStorage offline cache synchronization
│   │   └── appleEmojiCache.ts      # Zero-layout-shift emoji caching engine
│   ├── types.ts                    # Strict TypeScript Interfaces for all entities
│   ├── data.ts                     # Seed mocks and fallback datasets
│   ├── firebaseClient.ts           # Firestore & Auth SDK connection hub
│   ├── index.css                   # Tailwind CSS styling with dark/light theme tokens
│   └── App.tsx                     # Top-level Messenger orchestrator
├── firestore.rules                 # Enterprise Firestore RBAC & Encryption Security Rules
├── firebase-blueprint.json         # Database Schema, Indexes & Document Specifications
├── package.json                    # Isolated dependencies
└── vite.config.ts                  # Vite build bundler configuration
```

---

## 🚀 Quickstart: Running as Standalone Web App

1. **Install Dependencies**:
   ```bash
   npm install
   ```
2. **Start Local Development Server**:
   ```bash
   npm run dev
   ```
3. Open `http://localhost:3000` to interact with the standalone messenger.

---

## 📱 Porting to Native Platforms (React Native / Expo)

All business logic (`chatUtils.ts`, `cryptoUtils.ts`, `dateUtils.ts`, `presenceUtils.ts`, `audioUtils.ts`) is written in standard TypeScript and can be reused directly in React Native without modification.

### UI Component Mapping:
| Web Component | React Native / Expo Equivalent |
|---|---|
| `div`, `span`, `p` | `View`, `Text` |
| `motion/react` | `react-native-reanimated` |
| `AppleComposerInput` | `TextInput` + `KeyboardAvoidingView` |
| `lucide-react` | `lucide-react-native` or `@expo/vector-icons` |
| WebRTC `CallModal` | `react-native-webrtc` |
| `audioUtils` | `expo-av` or `react-native-audio-recorder-player` |

---

## 🔒 Security & Cryptography Model

1. **End-to-End Encryption (E2EE)**: Messages and media attachments are encrypted using AES-256-GCM before transport.
2. **Deterministic DM Generation**: Single 1-to-1 chat documents are uniquely identified by `chat_dm_${[userA, userB].sort().join('_')}` preventing duplicate channels.
3. **Database Rules**: `firestore.rules` enforces participant-level authorization, ensuring only chat members can read/write messages.

---

## 📄 License
Proprietary & Confidential - Zenoa Sovereign Communication Systems.
